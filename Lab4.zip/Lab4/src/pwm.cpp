// Author:
// Net ID:
// Date:
// Assignment:     Lab 4
//
// Description: This file implements PWM signal generation on Timer 3
// (and optionally Timer 4) to control DC motor speed and direction
// via the L293D driver.
//----------------------------------------------------------------------//

#include "pwm.h"

/*
 * Initializes PWM output on Timer 3 (and optionally Timer 4).
 * Set appropriate PWM mode and output pin(s).
 */
void initPWM(){
    // Motor direction pins: PE4 (IN1) and PE5 (IN2) on L293D
    DDRE |= (1 << DDE4) | (1 << DDE5); // Set PE4 and PE5 as outputs
    
    
    // TODO: Configure Timer3 for PWM mode (Fast PWM or Phase Correct)
    //       using WGM bits in TCCR3A/TCCR3B

    TCCR3A |= ((1 << WGM31) | (1 << WGM30));
    TCCR3B |= (1 << WGM32) | (1<<CS31);
    TCCR3B &= ~((1 << WGM33) |(1<<CS30)|(1<<CS32));
    

    // TODO: Set OC3A output pin (PE3, Arduino pin 5) direction via DDRE
    DDRE |= (1<<DDE3);
    // TODO: Configure compare output mode (COM3A bits in TCCR3A) will need to decide 
    TCCR3A |= (1<<COM3A1);
    TCCR3A &= ~(1<<COM3A0);
    // TODO: Set prescaler (CS3x bits in TCCR3B)
    OCR3A = 0; // Start with motor off
}

/*
 * Changes the duty cycle of the PWM signal based on the 10-bit ADC value.
 * The adcValue is the combination of ADCH and ADCL (0-1023).
 */
void changeDutyCycle(unsigned int adcValue){
    unsigned int dutyCycle;

    // Midpoint is 512 (~2.5V). Below = clockwise, above = counterclockwise.
    // Dead zone of +/-20 around midpoint prevents ADC noise from rapidly
    // flipping motor direction, which causes EMI that glitches INT0/SSD.
    if (adcValue < 492) {
        // Map 0→1023 (max CW), 491→~0 (stopped)
        dutyCycle = ((uint32_t)(492 - adcValue) * 1023) / 492;
        PORTE |= (1 << PORTE4);   // Clockwise: PE4 = HIGH, PE5 = LOW
        PORTE &= ~(1 << PORTE5);
    }
    else if (adcValue > 532) {
        // Map 533→~0 (stopped), 1023→1023 (max CCW)
        dutyCycle = ((uint32_t)(adcValue - 532) * 1023) / 491;
        PORTE |= (1 << PORTE5);   // Counterclockwise: PE4 = LOW, PE5 = HIGH
        PORTE &= ~(1 << PORTE4);
    }
    else {
        dutyCycle = 0;
        PORTE &= ~((1 << PORTE4) | (1 << PORTE5)); // Stop: both LOW
    }

    OCR3A = dutyCycle;
}
